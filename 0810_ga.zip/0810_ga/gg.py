A = [2, 3]
B = [[2,[6,1]], [3,[4]]]
result = None
for i in range(len(A)):
    for j in range(len(B)):
        if A[i] == B[j][1]:
            temp = len(B[j][1])
            if temp > B[j][1]:
                result = B[j][1]

print(result)
